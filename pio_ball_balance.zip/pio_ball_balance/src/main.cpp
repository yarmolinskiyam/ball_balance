#include <Arduino.h>

#include "overlord.h"
#include "student.h"

#define BUTTON 13

Overlord &overlord = Overlord::getInstance ();

void setup()
{
  Serial.begin (115200);

  pinMode (BUTTON, INPUT_PULLUP);

  overlord.init (controllerTick);

  controllerInit (overlord);
}

void loop ()
{
  overlord.tick ();
}
