#include "student.h"

/**
 * @brief Инициализировать систему управления
 * @details Вызывется один раз перед вызовом
 * функции \p controllerTick
 */
void controllerInit (Overlord &over)
{
    over.setSlider (SliderEnum::prog1, -12000, 12000);
    over.setSlider (SliderEnum::prog2, -10000, 10000);
}


/**
 * @brief Выполнить одну итерацию системы управления
 * @details Вызывается раз в 5мс
 */
void controllerTick (Overlord &over)
{
    float setPoint = over.getSetpoint ();

    bool button = !digitalRead (13);
    float u = button * over.getSlider (SliderEnum::prog1) * 0.001;

    float motorVel = over.getMotorVel ();

    over.setMotorU (u);

    Serial.print (u);
    Serial.print ('\t');
    Serial.print (motorVel);
    Serial.print ('\t');
    Serial.println ();
}
