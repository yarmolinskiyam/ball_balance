#include "carriage.h"

Carriage::Carriage (uint32_t trackLength, uint32_t carLength)
{
    static Ultrasonic sonarL_ (7, 6, 1000000/330);
    sonarL = &sonarL_;

    halfTrackLength = trackLength / 2;
    halfCarLenght = carLength / 2;
    
    static PID dv (0, 0, 1, Tvel, Ts);
    velFilter = &dv;
    static PID dp (0, 1/Tpos, 0, 1, Ts);
    posFilter = &dp;
}

void Carriage::update ()
{
    // x = posFilter->tick ((sonarL->readf () - halfTrackLength - halfCarLenght) * 0.01);
    x = (sonarL->read () - halfTrackLength - halfCarLenght) * 0.01;
    // x = posFilter->tick (x - posFilter->getLast ());
    x_i = velFilter->tick (x);
}
