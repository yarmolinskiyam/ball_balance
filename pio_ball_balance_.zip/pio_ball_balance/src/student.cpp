#include "student.h"

/**
 * @brief Инициализировать систему управления
 * @details Вызывется один раз перед вызовом
 * функции \p controllerTick
 */
void controllerInit (Overlord &over)
{
    over.setSlider (SliderEnum::prog1, -12000, 12000);
    over.setSlider (SliderEnum::prog2, -10000, 10000);
}

/**
 * @brief Выполнить одну итерацию системы управления
 * @details Вызывается раз в 5мс
 */
void controllerTick (Overlord &over)
{
    /*!v Опрос слайдера чтобы получить инфу из внешнего мира */
    static float setPoint;
    setPoint = over.getSlider (SliderEnum::prog1);
    /*!v Опрос кнопки и перевод */
    setPoint *= !digitalRead (13) * 0.001;

    /*!v Переменная, хранящая скорость двигателя */
    static float vel;
    
    /*!v Опрос скорости двигателя */
    vel = over.getMotorVel ();

    /*!v Выдача напряжения на мотор */
    over.setMotorU (setPoint);

    /*!v Вывод отладочной информации */
    Serial.print (setPoint);
    Serial.print ('\t');
    Serial.print (vel);
    Serial.println ();
}
