#include "overlord.h"

Motor *motor;

Overlord::Overlord()
{
    static Carriage car_ (trackLength, carLength);
    static Motor motor_ (ticksPerRev, gearboxRatio);

    static Slider slider0 (A0);
    static Slider slider1 (A1);
    static Slider slider2 (A2);

    static Slider *sliders_[sliderCount] =
    {
        &slider0,
        &slider1,
        &slider2
    };

    sliders = sliders_;

    sliders[static_cast<int> (SliderEnum::setPoint)]->setSlider (-200, 200);
    
    car = &car_;
    motor = &motor_;

    timer = micros ();
}

Overlord& Overlord::getInstance ()
{
    static Overlord overlord;
    return overlord;
}

void Overlord::init (void (*controller_) (Overlord &))
{
    controller = controller_;
}

float Overlord::getSetpoint ()
{
    return sliders[static_cast<int> (SliderEnum::setPoint)]->getValue () * 0.001;
}

void Overlord::tick ()
{
    /*!v Эта переменная будет false если итерация цикла больше периода квантования */
    bool isTimeOk = false;
    while (micros () - timer < Tsmicros) isTimeOk = true;

    // if (!isTimeOk)
    // {
    //     unsigned long mcrs = micros ();
    //     Serial.print ("ПРЕВЫШЕН ПЕРИОД КВАНТОВАНИЯ НА [мкс]: ");
    //     Serial.println (mcrs - timer - Tsmicros);
    // }
    timer = micros ();

    motor->update ();
    car->update ();
    controller (*this);

    // float err = getSetpoint () - car->getX ();
    // integralError += err*err * Ts; 
}
